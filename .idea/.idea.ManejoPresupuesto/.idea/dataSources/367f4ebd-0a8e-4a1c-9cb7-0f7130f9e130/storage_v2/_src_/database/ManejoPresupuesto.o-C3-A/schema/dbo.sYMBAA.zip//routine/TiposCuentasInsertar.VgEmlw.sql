-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE TiposCuentasInsertar
	-- Add the parameters for the stored procedure here
	@Nombre nvarchar(50),
	@UsuarioId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @NuevoOrden int;
	SELECT @NuevoOrden = COALESCE(MAX(Orden), 0) + 1
	FROM TiposCuentas
	WHERE UsuarioId = @UsuarioId;

	INSERT INTO TiposCuentas(Nombre, UsuarioId, Orden)
	VALUES (@Nombre, @UsuarioId, @NuevoOrden);

	SELECT SCOPE_IDENTITY();
END
go

