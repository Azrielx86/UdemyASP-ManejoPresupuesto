-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Transaccion_Eliminar]
	-- Add the parameters for the stored procedure here
	@Id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TipoOperacionId int;
	DECLARE @Monto decimal(18,2);
	DECLARE @CuentaId int;

	SELECT @Monto = Monto, @TipoOperacionId = Categorias.TipoOperacionId,
	@CuentaId = CuentaId
	FROM Transacciones
	INNER JOIN Categorias
	ON Categorias.Id = Transacciones.CategoriaId
	WHERE Transacciones.Id = @Id;

	DECLARE @FactMul int = 1;
	if (@TipoOperacionId = 2)
		SET @FactMul = -1;

	SET @Monto = @Monto * @FactMul;

	-- Remover balance
	UPDATE Cuentas
	SET Balance -= @Monto
	WHERE Id = @CuentaId;

    -- Insert statements for procedure here
	DELETE Transacciones
	WHERE Id = @Id;
END
go

